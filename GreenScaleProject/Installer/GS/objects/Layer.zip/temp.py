#-------------------------------------------------------------------------------
# Name:        temp.py
# Purpose:     Green Scale Tool temp Module (file used for various notes)
#
# Author:      Holly Tina Ferguson
#
# Created:     15/09/2013
# Copyright:   (c) Holly Tina Ferguson 2013
# Licence:     The University of Notre Dame
#-------------------------------------------------------------------------------
import math
#import gprof2dot

# This is a practice file for generating charts for the GS Paper

